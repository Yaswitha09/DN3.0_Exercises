package com.example.BookstoreAPI.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity // Add this annotation to make it a JPA entity
public class Book {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @NotNull(message = "Title cannot be null")
        @Size(min = 1, max = 100, message = "Title must be between 1 and 100 characters")
        private String title;

        @NotNull(message = "Author cannot be null")
        @Size(min = 1, max = 100, message = "Author must be between 1 and 100 characters")
        private String author;

        @Min(value = 0, message = "Price must be positive")
        private double price;

        @NotNull(message = "ISBN cannot be null")
        @Size(min = 10, max = 13, message = "ISBN must be between 10 and 13 characters")
        private String isbn;

        @Version // For optimistic locking
        private Integer version;
}
