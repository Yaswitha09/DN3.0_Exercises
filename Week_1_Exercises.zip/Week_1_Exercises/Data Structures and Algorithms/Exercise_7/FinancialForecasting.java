public class FinancialForecasting {

    public static double calculateFutureValue(double initialValue, double growthRate, int periods) {
        // Base case: if there are no more periods, return the initial value
        if (periods == 0) {
            return initialValue;
        }
        // Recursive case: apply the growth rate for the current period and recurse for the remaining periods
        return calculateFutureValue(initialValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        double initialValue = 1000.0; // Initial investment
        double growthRate = 0.05;     // Growth rate of 5%
        int periods = 10;             // Number of periods (e.g., years)

        double futureValue = calculateFutureValue(initialValue, growthRate, periods);
        System.out.println("Future value after " + periods + " periods: $" + String.format("%.2f", futureValue));
    }
}
