public class Main 
{
    public static void main(String[] args) {
        // Create the model
        Student student = new Student("1", "Amaya", "A");

        // Create the view
        StudentView view = new StudentView();

        // Create the controller
        StudentController controller = new StudentController(student, view);

        // Display the initial details
        controller.updateView();

        // Update the model data through the controller
        controller.setStudentName("Aashika");
        controller.setStudentGrade("B");

        // Display the updated details
        controller.updateView();
    }
}
