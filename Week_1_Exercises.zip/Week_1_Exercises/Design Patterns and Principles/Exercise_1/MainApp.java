public class MainApp {
    public static void main(String[] args) {
        // Get instance of Logger
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();

        // Both logger1 and logger2 should refer to the same instance
        System.out.println("Logger 1 instance: " + logger1.hashCode());
        System.out.println("Logger 2 instance: " + logger2.hashCode());

        // Testing the logging functionality
        logger1.log("Logging message 1");
        logger2.log("Logging message 2");
    }
}